from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

class Prompt(BaseModel):
    prompt: str

@app.get('/')
def home():
    return {'message': 'MYRAAI backend running'}

@app.post('/generate')
def generate(data: Prompt):
    return {
        'code': f'Generated website for: {data.prompt}'
    }