import { useState } from 'react'
import axios from 'axios'

export default function Home() {
  const [prompt, setPrompt] = useState('')
  const [code, setCode] = useState('')

  const generate = async () => {
    const res = await axios.post('http://localhost:8000/generate', { prompt })
    setCode(res.data.code)
  }

  return (
    <div style={{padding:20}}>
      <h1>MYRAAI</h1>

      <textarea
        rows={6}
        style={{width:'100%'}}
        onChange={(e)=>setPrompt(e.target.value)}
      />

      <button onClick={generate}>Generate</button>

      <pre>{code}</pre>
    </div>
  )
}